import axios from 'axios';

const API_BASE_URL = '/api';

export const analyzeResumeAndJD = async (file, jobId) => {
  const formData = new FormData();
  formData.append('resume', file);
  formData.append('job_id', jobId);

  try {
    const response = await axios.post(`${API_BASE_URL}/match`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
  } catch (error) {
    console.error('Error calculating match score:', error);
    throw error;
  }
};

export const fetchAnalyticsData = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/analytics`);
    return response.data;
  } catch (error) {
    console.error('Error fetching analytics:', error);
    throw error;
  }
};

export const fetchJobs = async () => {
  const response = await axios.get(`${API_BASE_URL}/jobs`);
  return response.data;
};

export const checkApiHealth = async () => {
  const response = await axios.get(`${API_BASE_URL}/health`);
  return response.data;
};